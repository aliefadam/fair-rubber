<?php $__env->startSection('content'); ?>
    <div class="flex justify-between flex-wrap items-center mb-6">
        <h4 class="font-medium lg:text-2xl text-xl capitalize text-slate-900 inline-block ltr:pr-4 rtl:pl-4 mb-1 sm:mb-0">
            Dashboard
        </h4>
        
    </div>
    <div class="grid grid-cols-12 gap-5 mb-5">
        <div class="2xl:col-span-3 lg:col-span-4 col-span-12">
            <div class="bg-no-repeat bg-cover bg-center p-5 rounded-[6px] relative"
                style="background-image: url(/assets/images/all-img/widget-bg-2.png)">
                <div class="max-w-[180px]">
                    <h4 class="text-xl font-medium text-white mb-2">
                        <span class="block font-normal">Good evening,</span>
                        
                    </h4>
                    <p class="text-sm text-white font-normal">
                        Kabar Baik Hari Ini ?
                    </p>
                </div>
            </div>
        </div>
        <div class="2xl:col-span-9 lg:col-span-8 col-span-12">
            <div class="grid md:grid-cols-3 grid-cols-1 gap-4">
                <!-- BEGIN: Group Chart -->
                <div class="card">
                    <div class="card-body pt-4 pb-3 px-4">
                        <div class="flex space-x-3 rtl:space-x-reverse">
                            <div class="flex-none">
                                <div
                                    class="h-12 w-12 rounded-full flex flex-col items-center justify-center text-2xl bg-[#e9ffe5] dark:bg-slate-900	 text-success-500">
                                    <iconify-icon icon=heroicons:shopping-cart></iconify-icon>
                                </div>
                            </div>
                            <div class="flex-1">
                                <div class="text-slate-600 dark:text-slate-300 text-sm mb-1 font-medium">
                                    Pendapatan (E)
                                </div>
                                <div class="text-slate-900 dark:text-white text-lg font-medium">
                                    
                                </div>
                            </div>
                        </div>
                        <div class="ltr:ml-auto rtl:mr-auto max-w-[124px]">
                            <div id="spae-line1"></div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body pt-4 pb-3 px-4">
                        <div class="flex space-x-3 rtl:space-x-reverse">
                            <div class="flex-none">
                                <div
                                    class="h-12 w-12 rounded-full flex flex-col items-center justify-center text-2xl bg-[#fffde5] dark:bg-slate-900	 text-warning-500">
                                    <iconify-icon icon=heroicons:shopping-cart></iconify-icon>
                                </div>
                            </div>
                            <div class="flex-1">
                                <div class="text-slate-600 dark:text-slate-300 text-sm mb-1 font-medium">
                                    Pendapatan (U)
                                </div>
                                <div class="text-slate-900 dark:text-white text-lg font-medium">
                                    
                                </div>
                            </div>
                        </div>
                        <div class="ltr:ml-auto rtl:mr-auto max-w-[124px]">
                            <div id="spae-line3"></div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body pt-4 pb-3 px-4">
                        <div class="flex space-x-3 rtl:space-x-reverse">
                            <div class="flex-none">
                                <div
                                    class="h-12 w-12 rounded-full flex flex-col items-center justify-center text-2xl bg-[#FFEDE6] dark:bg-slate-900	 text-warning-500">
                                    <iconify-icon icon=heroicons:cube></iconify-icon>

                                </div>
                            </div>
                            <div class="flex-1">
                                <div class="text-slate-600 dark:text-slate-300 text-sm mb-1 font-medium">
                                    Produk Terjual
                                </div>
                                <div class="text-slate-900 dark:text-white text-lg font-medium">
                                    
                                </div>
                            </div>
                        </div>
                        <div class="ltr:ml-auto rtl:mr-auto max-w-[124px]">
                            <div id="spae-line2"></div>
                        </div>
                    </div>
                </div>

                <!-- END: Group Chart -->
            </div>
        </div>
    </div>

    <div class="grid grid-cols-12 gap-5 mb-5">

        <div class="2xl:col-span-12 lg:col-span-12 col-span-12">
            <div class="grid md:grid-cols-5 grid-cols-1 gap-4">
                <!-- BEGIN: Group Chart -->
                <div class="card">
                    <div class="card-body pt-4 pb-3 px-4">
                        <div class="flex space-x-3 rtl:space-x-reverse">
                            <div class="flex-none">
                                <div
                                    class="h-12 w-12 rounded-full flex flex-col items-center justify-center text-2xl bg-[#ffe3d9] dark:bg-slate-900 text-danger-500">
                                    <i class="fa-light fa-money-bill"></i>
                                </div>
                            </div>
                            <div class="flex-1">
                                <div class="text-slate-600 dark:text-slate-300 text-sm mb-1 font-medium">
                                    Belum Bayar
                                </div>
                                <div class="text-slate-900 dark:text-white text-lg font-medium">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body pt-4 pb-3 px-4">
                        <div class="flex space-x-3 rtl:space-x-reverse">
                            <div class="flex-none">
                                <div
                                    class="h-12 w-12 rounded-full flex flex-col items-center justify-center text-2xl bg-[#e6f7ff] dark:bg-slate-900	 text-info-500">
                                    <i class="fa-light fa-circle-check"></i>
                                </div>
                            </div>
                            <div class="flex-1">
                                <div class="text-slate-600 dark:text-slate-300 text-sm mb-1 font-medium">
                                    Dikonfimasi
                                </div>
                                <div class="text-slate-900 dark:text-white text-lg font-medium">
                                    
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="card">
                    <div class="card-body pt-4 pb-3 px-4">
                        <div class="flex space-x-3 rtl:space-x-reverse">
                            <div class="flex-none">
                                <div
                                    class="h-12 w-12 rounded-full flex flex-col items-center justify-center text-2xl bg-[#fffce6] dark:bg-slate-900	 text-[#9dbe43]">
                                    <i class="fa-light fa-arrows-rotate-reverse"></i>
                                </div>
                            </div>
                            <div class="flex-1">
                                <div class="text-slate-600 dark:text-slate-300 text-sm mb-1 font-medium">
                                    Diproses
                                </div>
                                <div class="text-slate-900 dark:text-white text-lg font-medium">
                                    
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="card">
                    <div class="card-body pt-4 pb-3 px-4">
                        <div class="flex space-x-3 rtl:space-x-reverse">
                            <div class="flex-none">
                                <div
                                    class="h-12 w-12 rounded-full flex flex-col items-center justify-center text-2xl bg-[#EAE6FF] dark:bg-slate-900	 text-[#5743BE]">
                                    <i class="fa-sharp fa-light fa-truck-moving"></i>
                                </div>
                            </div>
                            <div class="flex-1">
                                <div class="text-slate-600 dark:text-slate-300 text-sm mb-1 font-medium">
                                    Pengiriman
                                </div>
                                <div class="text-slate-900 dark:text-white text-lg font-medium">
                                    
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="card">
                    <div class="card-body pt-4 pb-3 px-4">
                        <div class="flex space-x-3 rtl:space-x-reverse">
                            <div class="flex-none">
                                <div
                                    class="h-12 w-12 rounded-full flex flex-col items-center justify-center text-2xl bg-[#eaffe6] dark:bg-slate-900	 text-success-500">
                                    <i class="fa-light fa-box-check"></i>
                                </div>
                            </div>
                            <div class="flex-1">
                                <div class="text-slate-600 dark:text-slate-300 text-sm mb-1 font-medium">
                                    Selesai
                                </div>
                                <div class="text-slate-900 dark:text-white text-lg font-medium">
                                    
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- END: Group Chart -->
            </div>
        </div>
    </div>
    <div class="grid grid-cols-12 gap-5">
        <div class="2xl:col-span-8 lg:col-span-7 col-span-12">
            <div class="card">
                <div class="card-body p-6">
                    <div class="legend-ring">
                        <div id="column-bar-charts"></div>

                        
                    </div>
                </div>
            </div>
        </div>
        <div class="2xl:col-span-4 lg:col-span-5 col-span-12">
            <div class="card">
                <header class="card-header">
                    <h4 class="text-2xl poppins-medium">Informasi</h4>
                    <div>
                        <!-- BEGIN: Card Dropdown -->
                        
                        <!-- END: Card Droopdown -->
                    </div>
                </header>


                <div class="card-body p-6">
                    <div class="grid md:grid-cols-2 grid-cols-1 gap-5">
                        <div class="bg-slate-50 dark:bg-slate-900 rounded pt-3 px-4">
                            <div class="text-sm text-slate-600 dark:text-slate-300 mb-[6px]">
                                Total Pengguna
                            </div>
                            <div class="text-lg text-slate-900 dark:text-white font-medium mb-[6px]">
                                
                            </div>
                            <div class="mt-4">
                                <div class="bar-chart" colors="#FA916B" height="44"></div>
                            </div>
                        </div>
                        <!-- end single -->
                        <div class="bg-slate-50 dark:bg-slate-900 rounded pt-3 px-4">
                            <div class="text-sm text-slate-600 dark:text-slate-300 mb-[6px]">
                                Pesanan Masuk
                            </div>
                            <div class="text-lg text-slate-900 dark:text-white font-medium mb-[6px]">
                                
                            </div>
                            
                            
                            
                            
                            
                            <div class="mt-4">
                                <div class="line-chart" colors="#4669fa" height="44"></div>
                            </div>
                        </div>
                        <!-- end single -->
                        <div class="md:col-span-2">
                            <div class="bg-slate-50 dark:bg-slate-900 rounded pt-3 px-4">
                                <div class="flex items-center">
                                    <div class="flex-none">
                                        <div class="text-sm text-slate-600 dark:text-slate-300 mb-[6px]">
                                            Pendapatan Keseluruhan
                                        </div>
                                        <div class="text-lg text-slate-900 dark:text-white font-medium mb-[6px]">
                                            
                                        </div>
                                        

                                        <div class="font-normal text-xs text-slate-600 dark:text-slate-300">
                                            <span  (Earned) <br>
                                                <span  (Unearned) </div>
                                        </div>
                                        <div class="flex-1">
                                            <div class="legend-ring2">
                                                <div id="donut-chart-income" class="donut-chart-income" height="180"
                                                    colors="#F1595C,#0CE7FA" hidelabel="hideLabel" size="65%">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="xl:col-span-6 col-span-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="text-2xl poppins-medium">Pelanggan Setia</h4>

                    </div>
                    <div class="card-body p-6">
                        <!-- BEGIN: Customer Card -->
                        <div class="pb-2">
                            
                            <div class="grid grid-cols-1 gap-5 mt-5">


                            </div>
                        </div>
                        <!-- END: Customer Card -->
                    </div>
                </div>
            </div>

            <div class="xl:col-span-6 col-span-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="text-2xl poppins-medium">Pelanggan Terbaru</h4>

                    </div>
                    <div class="card-body p-6">
                        <!-- BEGIN: Customer Card -->
                        <div class="pb-2">
                            
                            <div class="grid grid-cols-1 gap-5 mt-5">


                            </div>
                        </div>
                        <!-- END: Customer Card -->
                    </div>
                </div>
            </div>
            <div class="xl:col-span-12 col-span-12">
                <div class="card">
                    <div class="card-header noborder">
                        <h4 class="text-2xl poppins-medium">Pesanan Terbaru
                        </h4>
                        
                    </div>
                    <div class="card-body p-6">
                        <!-- BEGIN: Order table -->
                        <div class="overflow-x-auto -mx-6">
                            <div class="inline-block min-w-full align-middle">
                                <div class="overflow-hidden ">
                                    <table class="min-w-full divide-y divide-slate-100 table-fixed dark:divide-slate-700">
                                        <thead class=" bg-slate-200 dark:bg-slate-700">
                                            <tr>
                                                <th scope="col" class=" table-th ">
                                                    Cust
                                                </th>
                                                <th scope="col" class=" table-th ">
                                                    Invoice
                                                </th>
                                                <th scope="col" class=" table-th ">
                                                    Harga
                                                </th>
                                                <th scope="col" class=" table-th ">
                                                    Status
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody
                                            class="bg-white divide-y divide-slate-100 dark:bg-slate-800 dark:divide-slate-700">



                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- END: Order Table -->
                    </div>
                </div>
            </div>


            <div class="xl:col-span-6 col-span-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="text-2xl poppins-medium">Produk Terbaru</h4>

                    </div>
                    <div class="card-body p-6">
                        <!-- BEGIN: Products -->
                        <div class="grid md:grid-cols-3 grid-cols-1 gap-5">



                        </div>
                        <!-- END: Product -->
                    </div>
                </div>
            </div>
            <div class="xl:col-span-6 col-span-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="text-2xl poppins-medium">Produk Terlaris</h4>

                    </div>
                    <div class="card-body p-6">
                        <!-- BEGIN: Products -->
                        <div class="grid md:grid-cols-3 grid-cols-1 gap-5">



                        </div>
                        <!-- END: Product -->
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\fair-rubber\resources\views/dashboard.blade.php ENDPATH**/ ?>